---
date: '2015-12-21'
title: 'Intern'
company: 'TechinNext'
location: 'Hyderabad, India'
range: 'May 2019- July 2019'
#url: 'https://techienest.in/'
---

- Worked on developing an age, gender and emotion classification model for the facial features using Keras and OpenCV. 
<!-- - Engineered and maintained major features of Starry's customer-facing web app using ES6, Handlebars, Backbone, Marionette and CSS
- Proposed and implemented scalable solutions to issues identified with cloud services and applications responsible for communicating with Starry Station
- Interfaced with user experience designers and other developers to ensure thoughtful and coherent user experiences across Starry’s iOS and Android mobile apps -->
