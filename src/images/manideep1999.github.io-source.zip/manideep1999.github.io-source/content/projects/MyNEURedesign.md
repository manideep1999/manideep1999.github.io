---
date: '2017-04-03'
title: 'myNEU Redesign'
github: 'https://github.com/bchiang7/Redesign-myNEU'
external: 'https://bchiang7.github.io/Redesign-myNEU/'
tech:
  - Jekyll
  - SCSS
  - JS
company: 'Northeastern'
showInProjects: false
---

Student web portal prototype built after conducting multiple rounds of user testing that aimed to improve the current portal to provide students at Northeastern University with a better user experience.
