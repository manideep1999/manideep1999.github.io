---
date: '2019-11-12'
title: 'Building a Headless Mobile App CMS From Scratch'
github: ''
external: 'https://medium.com/stories-from-upstatement/building-a-headless-mobile-app-cms-from-scratch-bab2d17744d9'
tech:
  - Node
  - Express
  - Firebase
  - Vue
company: 'Upstatement'
showInProjects: false
---

Find out how we built a custom headless CMS with Node, Express, and Firebase for a project at Upstatement
