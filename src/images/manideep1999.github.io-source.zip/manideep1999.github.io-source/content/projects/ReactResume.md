---
date: '2016-08-01'
title: 'React Profile'
github: 'https://github.com/bchiang7/react-profile'
external: 'https://bchiang7.github.io/react-profile/'
tech:
  - React
  - CSS
showInProjects: false
---

Online version of my 2016 resume made for fun. I was interested in learning React.js, so I found a simple tutorial and it spun into a weekend project.
