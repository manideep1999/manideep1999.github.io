---
date: '2018-12-29'
title: 'Google Keep Clone'
github: 'https://github.com/bchiang7/google-keep-vue-firebase'
external: 'https://keep-vue.netlify.com/'
tech:
  - Vue
  - Firebase
showInProjects: false
---

A simple Google Keep clone built with Vue and Firebase.
