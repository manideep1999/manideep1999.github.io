---
date: '2017-03-01'
title: 'Crowd DJ'
github: 'https://github.com/crowddj/crowddj-react'
external: ''
tech:
  - React
  - Firebase
  - Spotify API
company: HackBeanpot 2017
showInProjects: false
---

Web app that allows people to crowdsource a party's music queue. Allows people to request songs, upvote songs, rate songs, etc. so the DJ can see how the crowd is feeling and queue songs accordingly. Won Best UI/UX Design at Hackbeanpot 2017.
