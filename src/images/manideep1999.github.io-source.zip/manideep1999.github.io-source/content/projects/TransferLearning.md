---
date: '2017-11-01'
title: 'Transfer Learning on Images'
github: ''
# external: 'https://www.theverge.com/2017/10/5/16433770/facebook-messenger-apple-music-bot-song-streaming'
tech:
  - Python
  - CNN
  - Jupyter
company: 'MAHE'
showInProjects: true
---

Build a simple CNN model to classify the image categorization on dog v/s cat dataset. From the baseline models, various image augmentation techniques were used to improve the accuracy using transfer learning.
