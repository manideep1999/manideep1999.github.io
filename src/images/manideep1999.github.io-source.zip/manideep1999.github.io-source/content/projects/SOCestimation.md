---
date: '2017-11-01'
title: 'Estimation of SoC'
github: ''
# external: 'https://www.theverge.com/2017/10/5/16433770/facebook-messenger-apple-music-bot-song-streaming'
tech:
  - Neural Nets
  - SoC
  - BeagleBone Black
  - Linux
company: 'Formula Manipal'
showInProjects: true
---

The State of Charge (SoC) was estimated from the Battery Management System using a back-propagation neural network via a Beagle Bone Black controller. 
