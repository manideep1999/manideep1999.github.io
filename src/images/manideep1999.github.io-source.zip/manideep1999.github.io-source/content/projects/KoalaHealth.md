---
date: '2021-09-01'
title: 'Koala Health'
github: ''
external: 'https://www.koala.health/'
tech:
  - Next.js
  - TypeScript
  - Redux Toolkit
  - Stripe
  - Algolia
  - Firebase Auth
  - Formik
  - Yup
  - Vercel
company: 'Upstatement'
showInProjects: false
---
