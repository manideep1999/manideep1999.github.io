---
date: '2021-07-01'
title: 'Philadelphia Inquirer Sports Scoreboards'
github: ''
external: 'https://www.inquirer.com/sports/'
tech:
  - React
  - TypeScript
  - Stats Perform API
company: 'Upstatement'
showInProjects: false
---
