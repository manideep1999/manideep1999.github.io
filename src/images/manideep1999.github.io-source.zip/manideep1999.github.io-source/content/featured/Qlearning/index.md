---
date: '3'
title: 'Reinforcement Learning-Atari Games'
cover: './qlearning.png'
#external: 'https://www.newline.co/courses/build-a-spotify-connected-app'
cta: 'https://www.google.com'
tech:
  - Python API
  - Gym
  - TensorFlow
---

Implemented and compared the performances of various Reinforcement Learning Techniques like Q-learning, DQN, etc on various Atari Games like breakout, pong, etc
 <!-- Later, optimized the network to perform better than than initial one.  -->