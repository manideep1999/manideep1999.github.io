module.exports = require('@upstatement/prettier-config');
